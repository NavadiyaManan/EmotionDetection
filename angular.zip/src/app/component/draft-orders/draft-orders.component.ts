import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-draft-orders',
  templateUrl: './draft-orders.component.html',
  styleUrls: ['./draft-orders.component.css']
})
export class DraftOrdersComponent implements OnInit {

  

  isLinear = false;
  ProductId: any[] = [];
  AddressId:any[]=[]; 
  constructor(private builder:FormBuilder,private service: ServiceService,private router :Router) {}
 
     AddOrder : FormGroup = new FormGroup ({
      Note : new FormControl(''),
      DisountAmount: new FormControl(''),
      CustomerName: new FormControl(''),
      CustomerContactNo: new FormControl(''),
      
     })

    orderItem:FormGroup=new FormGroup({
      ProductId:new FormControl(''),
      Quantity:new FormGroup('')
    })
    AddressIdForm:FormGroup=new FormGroup({
      AddressId:new FormControl('')
    })

    selectedProductId = new FormControl();

 
     ngOnInit(): void {
      this.AddOrder = this.builder.group({
        Note:['',[Validators.required]],
        DisountAmount:['', [Validators.required]],
        CustomerName: ['', [Validators.required]],
        CustomerEmail: ['', [Validators.required]],
        CustomerContactNo: ['', [Validators.required]],
       
      })

      this.orderItem=this.builder.group({
        ProductId:['',[Validators.required]],
        Quantity:['',[Validators.required]]
      })

      this.AddressIdForm=this.builder.group({
        AddressId:['',Validators.required]
      })
     }
   
     

     get d(): { [key: string]: AbstractControl } {
       return this.AddOrder.controls;
     }


     fetchProducts() {
      this.service.getOrder().subscribe(
        (res:any) => {
          this.ProductId = res;
          this.AddressId=res;
        },
        (error:any) => {
          console.error('Failed to fetch products:', error);
        }
      );

     }
     userlogin(){
      console.log(this.AddOrder.value)
      // console.log(this.orderItem.value)
        //  this.service.AddOrder(this.AddOrder.value)
     }

     submitOrder() {
      if (this.AddOrder.invalid || this.orderItem.invalid || this.AddressIdForm.invalid) {
        // Handle form validation errors
        return;
      }
    
      const orderData = {
        orderDetails: this.AddOrder.value,
        orderItems: this.orderItem.value,
        addressId: this.AddressIdForm.value.AddressId
      };
    
      this.service.createDraftOrder(orderData).subscribe(
        (respons:any) => {
          // Handle successful response from the backend
          // console.log('Draft order created successfully:', response);
          // Redirect or perform other actions as needed
          this.router.navigate(['/success']);
        },
        (error:any) => {
          // Handle error response from the backend
          console.error('Failed to create draft order:', error);
          // Display error message or perform other actions as needed
        }
      );
    }
    
}

