import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  LoginForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private service: ServiceService,private router : Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.LoginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(2)]],
     
      password: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  onSubmit() {
    if (this.LoginForm.valid) {
      // Process registration logic here
      this.service.Login(this.LoginForm.value).subscribe((res:any)=>{
        console.log("Login successfully",res);
        localStorage.setItem('token', res.token);
     
        this.toastr.success('Login Successfully', 'Congrats ');
        this.router.navigateByUrl("")
      },
      (error) => {
        // Handle login error
        console.log('Login failed', error);
        this.toastr.error('Login Failed', 'Error');
      })
     
    }
  }
}