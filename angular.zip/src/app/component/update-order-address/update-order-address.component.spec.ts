import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOrderAddressComponent } from './update-order-address.component';

describe('UpdateOrderAddressComponent', () => {
  let component: UpdateOrderAddressComponent;
  let fixture: ComponentFixture<UpdateOrderAddressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateOrderAddressComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateOrderAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
