import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-order-address',
  templateUrl: './update-order-address.component.html',
  styleUrls: ['./update-order-address.component.css']
})
export class UpdateOrderAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
