import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Token } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { catchError } from "rxjs/internal/operators/catchError";
import { throwError } from "rxjs/internal/observable/throwError";
import { ErrorServiceService } from './error-service.service';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http: HttpClient,
    private router: Router,
    private errorservice: ErrorServiceService,
    private toastr: ToastrService) { }
  base_url = "https://phplaravel-886096-3128455.cloudwaysapps.com/api";

  // regsitration service 
  register(data: any) {
   
    return this.http.post(`https://localhost:7127/api/Auth/AddUser`, data).pipe(
      catchError((error) => {
        this.errorservice.handleError(error);
        return throwError(error);
      })
    );;
  }

  // login service
  login(data: any) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    return this.http.post("https://localhost:7127/api/Auth/login", data, { headers }).pipe(
      catchError((error) => {
        this.errorservice.handleError(error);
        return throwError(error);
      })
    );
  }

  //check for login
  isLoggedIn() {
    return localStorage.getItem('token') != null
  }

  //logout 
  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('first_name');
    this.router.navigate(['auth/login']);

  }

  //set header for token  
  header = new HttpHeaders({
    'accept': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  })

  //change password service
  changePassword(data: any) {
    const token = localStorage.getItem('token');
    console.log(token)

    return this.http.post(`${this.base_url}/v1/change-password`, data, { headers: this.header }).pipe(
      catchError((error) => {
        this.errorservice.handleError(error);
        return throwError(error);
      })
    );;
  }

  //get Data service
  getData() {
    return this.http.get(`http://localhost:7164/api/api/data`,{headers:this.header}).pipe(
      catchError((error) => {
        this.errorservice.handleError(error);
        return throwError(error);
      })
    );;
  }


  // uploadImage(){
  //   return this.http.post('https://localhost:7059/api/Empolyee/api/images',{headers:this.header}).pipe(
  //     catchError((error) => {
  //       this.errorservice.handleError(error);
  //       return throwError(error);
  //     })
  //   );
  // }
  uploadImage(imageFile: File) {
    const formData = new FormData();
    formData.append('imageFile', imageFile);

    return this.http.post('https://localhost:7059/api/Empolyee/api/images', formData);
  }

  // uploadImage(imageFile: File) {
  //   const formData = new FormData();
  //   formData.append('imageFile', imageFile);

  //   // Create the directory if it doesn't exist
  //   const directoryPath = imageFile.name.substring(0, imageFile.name.lastIndexOf('/'));
  //   Directory.CreateDirectory(directoryPath);

  //   return this.http.post(this.apiUrl, formData);
  // }
}
