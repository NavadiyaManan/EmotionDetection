import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from './auth/service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  title = 'crud';
 
  navBar=false
  ngOnInit(): void {
    // this.userDisplayName = localStorage.getItem('first_name');
    // let url=this.router.url;
    // if(url=="login"||url=="resgiter"||url=="dashboard/check-password"){
    //   this.navBar=false;
    // }
    // else{
    //   this.navBar=true;
    // }
  }
  constructor(private service:ServiceService,
    private router:Router,
     private dialog:MatDialog,
    private toastr: ToastrService) {
    
   }
   changePassword(){
    this.router.navigate(['dashboard/change-password'])
   }

  logout(){
    this.service.logout();
  }
}
