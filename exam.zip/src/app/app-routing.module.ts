import { registerLocaleData } from '@angular/common';
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardGuard } from './auth-guard.guard';
import { ChangePasswordComponent } from './component/change-password/change-password.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { LoginComponent } from './component/login/login.component';
import { RegsitrationComponent } from './component/regsitration/regsitration.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

const routes: Routes = [
  {path:'auth/registration',component:RegsitrationComponent},
  {path:'auth/login',component:LoginComponent},
  {path:'',component:RegsitrationComponent},
  // {path:'**',component:PagenotfoundComponent},
  // {path:'dashboard/:first_name',component:DashboardComponent,canActivate:[AuthGuardGuard]},
  {path:'dashboard',component:DashboardComponent},
  {path:'dashboard/change-password',component:ChangePasswordComponent,canActivate:[AuthGuardGuard]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
