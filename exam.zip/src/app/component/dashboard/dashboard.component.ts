import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Route, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/auth/service.service';
import { MatPaginator } from '@angular/material/paginator'
import { MatSort } from '@angular/material/sort'
import { MatDialog } from '@angular/material/dialog'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {
  list :any=[];
  searchData: any;
  dataSource: any;
  currentPage = 1;
  pageSize = 10;
  i:any;
  userDisplayName: any = '';
  displayedColumns: string[] = ['name', 'description', 'isActive', 'price', 'quantity','Action'];


  bookdata : any[]=[];


  constructor(private service: ServiceService,
    private router: Router,
    private dialog: MatDialog,
    private toastr: ToastrService) {
    this.getData();
  }

  ngOnInit(): void {
    this.userDisplayName = localStorage.getItem('first_name');
  }

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  //get data 
  getData() {
    this.service.getData().subscribe((res: any) => {
      this.list = res;
      this.bookdata=res;
      for (let i = 0; i < this.list.length; i++) {
        console.log("hello",res);
        
      }
      
   this.dataSource = new MatTableDataSource(this.list);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    });
  }
  selectedImage: File | null = null;

  onFileSelected(event: any) {
    this.selectedImage = event.target.files[0] as File;
  }
  onUpload(){
    if (this.selectedImage) {
      this.service.uploadImage(this.selectedImage)
        .subscribe(
          () => {
            console.log('Image uploaded successfully.');
            // Handle success, show a success message, or perform any other action
          },
          (error:any) => {
            console.log('Image upload failed:', error);
            // Handle error, show an error message, or perform any other action
          }
        );
      }
    }

  //search data
  SearchData() {
    const search = this.searchData.toLowerCase();
    this.dataSource.filter = search.trim().toLowerCase();

  }

  //change password
  changePassword() {
    this.router.navigate(['dashboard/change-password'])
  }

  //logout
  logout() {
    this.service.logout();
  }

  //update funcation
  updataData() {
    
    this.toastr.warning('Not work Yet !');
  }

  DeleteData(){
    this.toastr.warning('Not work Yet !');
  }

}
