import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/auth/service.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  submitted = false;



  changePasswordForm: FormGroup = new FormGroup({

    password: new FormControl(''),
    password_confirmation: new FormControl(''),
    newpassword: new FormControl(''),
  });
  constructor(private formBuilder: FormBuilder, private service: ServiceService,
    private router: Router, private toastr: ToastrService) {
    this.changePasswordForm = this.formBuilder.group({
      password: ['', Validators.required],
      password_confirmation: ['', Validators.required],
      newpassword: ['', Validators.required]
    });
  }

  ngOnInit(): void { }

  changePassword() {
    this.submitted = true;
    if (this.changePasswordForm.valid) {
      this.service.changePassword(this.changePasswordForm.value)
        .subscribe((res: any) => {

          this.toastr.success('Change password successfully');
          this.router.navigate(['auth/login']);
        }, (err: any) => {

          this.toastr.error('Please check password and new password');
        });

    }
    else {
      this.toastr.warning('Please Enter Valid Data')
    }
  }


  get password() { return this.changePasswordForm.get('password'); }
  get password_confirmation() { return this.changePasswordForm.get('password_confirmation'); }
  get newpassword() { return this.changePasswordForm.get('newpassword'); }

}
