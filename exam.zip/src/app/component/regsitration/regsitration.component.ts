import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/auth/service.service';
@Component({
  selector: 'app-regsitration',
  templateUrl: './regsitration.component.html',
  styleUrls: ['./regsitration.component.css']
})
export class RegsitrationComponent implements OnInit {

  register_disable =false;

  registerform: FormGroup = new FormGroup({
    UserName: new FormControl(''),
    last_name: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    age: new FormControl(''),
    phone_number: new FormControl(''),
    subscription_type: new FormControl('1')
  });
  submitted = false;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private service: ServiceService,
    private toastr: ToastrService) { }

  ngOnInit(): void {

    this.registerform = this.formBuilder.group({

      UserName: ['', [Validators.required, Validators.minLength(2)]],
    
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
    
    })
  }

  register() {
    this.submitted = true;
   
    if (this.registerform.valid) {
      this.service.register(this.registerform.value).subscribe((res: any) => {
        console.log(res)
        this.register_disable=true;
        this.toastr.success('Register Successfully');
        this.router.navigate(['auth/login']);
      });
    } 
    else 
    {
      this.toastr.warning('Please Enter Valid Data');
    }

  }

  get UserName() { return this.registerform.get('first_name'); }
 
  get email() { return this.registerform.get('email'); }
  get password() { return this.registerform.get('password'); }
 
}
