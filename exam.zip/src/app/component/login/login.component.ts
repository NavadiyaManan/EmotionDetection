import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/auth/service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });
  submitted = false;
  // isLoading=false;
  email: string = '';
  password: string = '';

  constructor(private auth: ServiceService,
    private router: Router,
    // private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private builder: FormBuilder) { localStorage.removeItem('user'); }

  ngOnInit(): void {
    // this.spinner.hide();
    this.loginform = this.builder.group(
      {
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(40)]],
      },
    );

  }



  get f(): { [key: string]: AbstractControl } {
    return this.loginform.controls;
  }
  // login Function
  login() {

   
    
    if (this.loginform.valid) {
      // this.isLoading=true;
      // this.spinner.show();

      this.submitted = true;
      this.auth.login(this.loginform.value).subscribe((res:any)=>{
        console.log(this.loginform.value)
      });
     
      this.email = '';
      this.password = '';
    }
  
  }
  
}
