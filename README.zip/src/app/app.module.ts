import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { AddAddressComponent } from './component/add-address/add-address.component';
import { GetOrdersComponent } from './component/get-orders/get-orders.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ServiceService } from './service.service';
import { GetAddressListComponent } from './component/get-address-list/get-address-list.component';
import { materialmodule } from './component/material.module';
import { DraftOrdersComponent } from './component/draft-orders/draft-orders.component';
import { ToastrModule } from 'ngx-toastr';
import { UpdateOrderStatusComponent } from './component/update-order-status/update-order-status.component';
import { UpdateOrderAddressComponent } from './component/update-order-address/update-order-address.component';
import { ProductComponent } from './component/product/product.component';

@NgModule({
  declarations: [
    AppComponent,
    
    LoginComponent,
    RegistrationComponent,
    DashboardComponent,
    AddAddressComponent,
    GetOrdersComponent,
    GetAddressListComponent,
    DraftOrdersComponent,
    UpdateOrderStatusComponent,
    UpdateOrderAddressComponent,
    ProductComponent
    
 ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    materialmodule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    ToastrModule.forRoot(),

  ],
  providers: [ ],
  bootstrap: [AppComponent]
})
export class AppModule { }
