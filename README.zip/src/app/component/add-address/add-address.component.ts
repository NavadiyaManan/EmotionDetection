import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-add-address',
  templateUrl: './add-address.component.html',
  styleUrls: ['./add-address.component.css']
})
export class AddAddressComponent {

AddAddressform: FormGroup = new FormGroup({
  addressType: new FormControl(''),
  AddressLine: new FormControl(''),
  ZipCode: new FormControl(''),
  Country: new FormControl(''),
  State: new FormControl(''),
  City: new FormControl(''),
  ContactPerson: new FormControl(''),
  ContactNo: new FormControl(''),
});


title = "Add Address"
submitted = false;
isLogin = false;
email: string = '';
password: string = '';


constructor(private builder: FormBuilder, private service: ServiceService,
  private http : HttpClient,private toastr:ToastrService, private router:Router) {}
ngOnInit(): void {
  this.AddAddressform = this.builder.group(
    {
      addressType: ['', [Validators.required]],
      AddressLine: ['', [Validators.required]],
      ZipCode: ['', [Validators.required]],
      Country: ['', [Validators.required]],
      State: ['', [Validators.required]],
      City: ['', [Validators.required]],
      ContactPerson: ['', [Validators.required]],
      ContactNo: ['', [Validators.required]],
    },
  );
}
get f(): { [key: string]: AbstractControl } {
  return this.AddAddressform.controls;
}

onSubmit() {
console.log(this.AddAddressform.value)
  this.service.AddAddress(this.AddAddressform.value).subscribe((res:any)=>{
    console.log("Add data ",this.AddAddressform)
    this.toastr.success("Add Address SuccessFully ")
    this.router.navigateByUrl("dashboard")

  },Error=>this.toastr.error(Error.error))
  
}

}


