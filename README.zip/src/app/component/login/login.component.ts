import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  LoginForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private service: ServiceService,private router : Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.LoginForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(2)]],
     
      password: ['', [Validators.required, Validators.minLength(5)]]
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.LoginForm.controls;
  }

  onSubmit() {
    if (this.LoginForm.valid) {
      // Process registration logic here
      this.service.Login(this.LoginForm.value).subscribe((res:any)=>{
        console.log("Login successfully",res);
        localStorage.setItem('token', res.token);
     
        this.toastr.success('Login Successfully', 'Congrats ');
        this.router.navigateByUrl("dashboard")
      },
      (error) => {
        console.error("Login error:", error); 
        this.toastr.error('An error occurred during login.', 'Error');
      });
     
    }
  }
}