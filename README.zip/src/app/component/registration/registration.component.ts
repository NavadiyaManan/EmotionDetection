import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Toast, ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private service: ServiceService,private router : Router,private toastr:ToastrService) { }

  ngOnInit(): void {
    this.registrationForm = this.formBuilder.group({
      UserName: ['', [Validators.required, Validators.minLength(2)]],
      Email: ['', [Validators.required, Validators.email]],
      Password: ['', [Validators.required, Validators.minLength(5)]]
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.registrationForm.controls;
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      // Process registration logic here
      this.service.Register(this.registrationForm.value).subscribe((res:any)=>{
        console.log("Registration successfully",res);
        this.toastr.success('Regitration SuccessFully!', 'Now you can login');
        this.router.navigateByUrl("login")
      },  (error) => {
        console.error("Login error:", error); 
        this.toastr.error('An error occurred during login.', 'Error');
      });
     
    }
  }
}