import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-update-order-status',
  templateUrl: './update-order-status.component.html',
  styleUrls: ['./update-order-status.component.css']
})
export class UpdateOrderStatusComponent implements OnInit {
  orderId: any;

  selectedStatus: any;
  constructor(private router: ActivatedRoute, private service: ServiceService,
    private toastr: ToastrService,
    private route: Router) { }

  ngOnInit() {
    this.router.paramMap.subscribe(params => {
      this.orderId = params.get('orderId');
    });
  }

  updateStatus() {

    var data = {
      orderId: this.orderId,
      Status: this.selectedStatus
    }
    console.log(data)
    if (data.Status != null) {
      this.service.updatestatus(data).subscribe(res => 
        { 
          console.log("Go to api ",res) 
          this.toastr.success("Update Status Successfully")
          this.route.navigate(['/getOrders']);
        }, Error => this.toastr.error(Error.error));
      console.log(data)
    
    }
  }
}