
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCardModule } from '@angular/material/card';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgModule } from '@angular/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule}from '@angular/material/grid-list'
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatStepperModule} from '@angular/material/stepper';
import {MatSidenavModule} from '@angular/material/sidenav';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ProductComponent } from './product/product.component';

// import {MatStepperModule} from '@angular/material/stepper';
// import {MatCheckboxModule} from '@angular/material/checkbox';
// Material file 

@NgModule({
    exports: [
        MatInputModule,
        MatCardModule,
        MatCheckboxModule,
        MatDialogModule,
        MatSelectModule,
        MatStepperModule,
        MatSelectModule,
        MatRadioModule,
        MatFormFieldModule,
        MatTableModule, 
        MatListModule,
        MatProgressBarModule,
        MatPaginatorModule,
        MatSortModule,
        MatSidenavModule,
        MatSidenavModule,
        MatToolbarModule,
        MatButtonModule,
        MatAutocompleteModule,
        MatIconModule,
        MatNativeDateModule,
        BrowserAnimationsModule,
        MatDatepickerModule,
        MatSnackBarModule,
        MatProgressSpinnerModule,
        MatGridListModule,
    ],
    declarations: [
     
      
    
    
  ]
})
export class materialmodule {


}