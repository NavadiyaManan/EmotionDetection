import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  product :any=[];
  constructor(private router:Router,private service:ServiceService) { }

  ngOnInit(): void {
    this.getProduct();
  }
  getProduct(){
    this.service.fetchProducts().subscribe((res:any)=>{
      this.product=res
      console.log(this.product.value.name)
    });
  }
}
