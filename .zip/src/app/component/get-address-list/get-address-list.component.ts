import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-get-address-list',
  templateUrl: './get-address-list.component.html',
  styleUrls: ['./get-address-list.component.css']
})
export class GetAddressListComponent implements OnInit {
  list :any=[];
  searchData: any;
  dataSource: any;
  currentPage = 1;
  pageSize = 10;
  i:any;
  userDisplayName: any = '';
  shippingAddress:any=["'AddressLine','City','State','Country'"];
  displayedColumns: string[] = ['orderId','description', 'customerEmail', 'customerName','status','totalItems', 'totalAmount','addressLine'];


  bookdata : any[]=[];


  constructor(private service: ServiceService,
    private router: Router,
    private dialog: MatDialog,
    // private toastr: ToastrService
    ) {
    this.getData();
  }

  ngOnInit(): void {
    this.userDisplayName = localStorage.getItem('first_name');
  }

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  //get data 
  getData() {
    this.service.GetOrderData().subscribe((res: any) => {
      this.list = res;
      this.bookdata=res;
      for (let i = 0; i < this.list.length; i++) {
        console.log("hello",res);
        
      }
      
        this.dataSource = new MatTableDataSource(this.list);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    });
  }
  selectedImage: File | null = null;

  onFileSelected(event: any) {
    this.selectedImage = event.target.files[0] as File;
  }


  

}
