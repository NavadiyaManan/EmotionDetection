import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-draft-orders',
  templateUrl: './draft-orders.component.html',
  styleUrls: ['./draft-orders.component.css']
})
export class DraftOrdersComponent implements OnInit {

  category!:string;
  hide = true
  selectedValue!: string;
  City = [
    {value: 'Ahmedabad', viewValue: 'Ahmedabad'},
    {value: 'Amreli', viewValue: 'Amreli'},
    {value: 'Anand', viewValue: 'Anand'},
    {value: 'Banas Kantha', viewValue: 'Banas Kantha'},
    {value: 'Bharuch', viewValue: 'Bharuch'},
    {value: 'Bhavnagar', viewValue: 'Bhavnagar'},
    {value: 'Gandhinagar', viewValue: 'Gandhinagar'},
    {value: 'Jamnagar', viewValue: 'Jamnagar'},
    {value: 'Junagadh', viewValue: 'Junagadh'}

  ];

  State = [
    {value: 'Gujarat', viewValue: 'Gujarat'},
   

  ];
  firstFormGroup = this.builder.group({
    firstCtrl: ['', Validators.required],
  });
  secondFormGroup = this.builder.group({
    secondCtrl: ['', Validators.required],
  });
  isLinear = false;

  constructor(private builder:FormBuilder,private service: ServiceService) {}
 
     AddOrder : FormGroup = new FormGroup ({
      Note : new FormControl(''),
      DisountAmount: new FormControl(''),
      CustomerName: new FormControl(''),
      CustomerContactNo: new FormControl(''),
      
     })
 
     ngOnInit(): void {
      this.AddOrder = this.builder.group({
        Note:['',[Validators.required]],
        DisountAmount:['', [Validators.required]],
        CustomerName: ['', [Validators.required]],
        CustomerEmail: ['', [Validators.required]],
        CustomerContactNo: ['', [Validators.required]],
       
      })
     }
   
 
     get d(): { [key: string]: AbstractControl } {
       return this.AddOrder.controls;
     }
     userlogin(){
      console.log(this.AddOrder.value)
        //  this.service.AddOrder(this.AddOrder.value)
     }
}

