import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DraftOrdersComponent } from './draft-orders.component';

describe('DraftOrdersComponent', () => {
  let component: DraftOrdersComponent;
  let fixture: ComponentFixture<DraftOrdersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DraftOrdersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DraftOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
