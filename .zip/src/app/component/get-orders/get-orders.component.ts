import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-get-orders',
  templateUrl: './get-orders.component.html',
  styleUrls: ['./get-orders.component.css']
})
export class GetOrdersComponent implements OnInit {
  list :any=[];
  searchData: any;
  dataSource: any;
  currentPage = 1;
  pageSize = 10;
  i:any;
  userDisplayName: any = '';
  displayedColumns: string[] = ['addressType','addressLine', 'country', 'state','city','zipCode', 'contactPerson','contactNo',];


  bookdata : any[]=[];


  constructor(private service: ServiceService,
    private router: Router,
    private dialog: MatDialog,
    // private toastr: ToastrService
    ) {
    this.getData();
  }

  ngOnInit(): void {
    this.userDisplayName = localStorage.getItem('first_name');
  }

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  //get data 
  getData() {
    this.service.getData().subscribe((res: any) => {
      this.list = res;
      this.bookdata=res;
      for (let i = 0; i < this.list.length; i++) {
        console.log("hello",res);
        
      }
      
   this.dataSource = new MatTableDataSource(this.list);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    });
  }
  selectedImage: File | null = null;

  onFileSelected(event: any) {
    this.selectedImage = event.target.files[0] as File;
  }


  //search data
  SearchData() {
    const search = this.searchData.toLowerCase();
    this.dataSource.filter = search.trim().toLowerCase();

  }

  //change password
  AddAddress() {
    this.router.navigate(['AddAddress'])
  }

  //logout
  logout() {
    this.service.logout();
  }

  //update funcation
  // updataData() {
    
  //   this.toastr.warning('Not work Yet !');
  // }

  // DeleteData(){
  //   this.toastr.warning('Not work Yet !');
  // }

}
